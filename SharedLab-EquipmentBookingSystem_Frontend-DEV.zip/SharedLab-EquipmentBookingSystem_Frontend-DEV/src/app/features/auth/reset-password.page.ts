import { Component, computed, inject, signal } from '@angular/core'
import { toSignal } from '@angular/core/rxjs-interop'
import { firstValueFrom } from 'rxjs'
import { FormBuilder, ReactiveFormsModule, Validators } from '@angular/forms'
import { ActivatedRoute, Router, RouterLink } from '@angular/router'
import { AuthService } from '../../core/auth/auth.service'
import { AuthStore } from '../../core/auth/auth.store'
import { ApiError } from '../../core/http/api-error'

import {
  createResetPasswordPolicy,
  passwordMatchValidator,
  type PasswordRuleKey,
} from '../../core/auth/fluent-password.validator'
import { TranslatePipe } from '../../core/i18n/translate.pipe'

type ResetErrorKind = 'invalidToken' | 'sameAsOldPassword' | 'tooManyRequests' | 'generic' | null

@Component({
  selector: 'app-reset-password-page',
  standalone: true,
  imports: [ReactiveFormsModule, RouterLink, TranslatePipe],
  templateUrl: './reset-password.page.html',
})
export class ResetPasswordPage {
  private readonly route = inject(ActivatedRoute)
  private readonly router = inject(Router)
  private readonly fb = inject(FormBuilder)
  private readonly authService = inject(AuthService)
  private readonly authStore = inject(AuthStore)

  private readonly passwordPolicy = createResetPasswordPolicy()

  protected readonly token = this.route.snapshot.queryParamMap.get('token')
  protected readonly email = this.route.snapshot.queryParamMap.get('email')
  protected readonly linkInvalid = !this.token || !this.email

  protected readonly showNewPassword = signal(false)
  protected readonly showConfirmPassword = signal(false)
  protected readonly status = signal<'idle' | 'loading' | 'success'>('idle')
  protected readonly errorKind = signal<ResetErrorKind>(null)
  protected readonly errorDetail = signal<string | null>(null)

  protected readonly form = this.fb.nonNullable.group(
    {
      newPassword: ['', [Validators.required, this.passwordPolicy.toValidatorFn()]],
      confirmPassword: ['', [Validators.required]],
    },
    { validators: passwordMatchValidator('newPassword', 'confirmPassword') },
  )

  private readonly newPasswordValue = toSignal(this.form.controls.newPassword.valueChanges, {
    initialValue: '',
  })

  protected readonly checklist = computed<Record<PasswordRuleKey, boolean>>(() =>
    this.passwordPolicy.evaluate(this.newPasswordValue() ?? ''),
  )

  protected readonly ruleOrder: PasswordRuleKey[] = [
    'minLength',
    'uppercase',
    'lowercase',
    'digit',
    'special',
  ]

  constructor() {
    this.form.valueChanges.subscribe(() => {
      if (this.errorKind()) {
        this.errorKind.set(null)
        this.errorDetail.set(null)
      }
    })
  }

  toggleNewPassword(): void {
    this.showNewPassword.update((v) => !v)
  }

  toggleConfirmPassword(): void {
    this.showConfirmPassword.update((v) => !v)
  }

  async submit(): Promise<void> {
    if (this.form.invalid || !this.token || !this.email) {
      this.form.markAllAsTouched()
      return
    }

    this.status.set('loading')
    this.errorKind.set(null)
    this.errorDetail.set(null)

    try {
      await firstValueFrom(
        this.authService.resetPassword({
          email: this.email,
          token: this.token,
          newPassword: this.form.controls.newPassword.value,
        }),
      )
      this.status.set('success')
      setTimeout(() => {
        if (this.authStore.isAuthenticated()) {
          void this.router.navigateByUrl('/app/profile')
        } else {
          void this.router.navigateByUrl('/login')
        }
      }, 1000)
    } catch (e: any) {
      this.status.set('idle')

      // Bóc tách sâu payload error từ Backend (e.error, e.error.message, e.message)
      const rawError = e?.error ?? e
      const serverMessage = (
        typeof rawError === 'string'
          ? rawError
          : rawError?.message || rawError?.detail || e?.message || ''
      ).toString()

      const msgLower = serverMessage.toLowerCase()

      if (e instanceof ApiError && e.status === 429) {
        this.errorKind.set('tooManyRequests')
        this.errorDetail.set(serverMessage)
      } else if (e instanceof ApiError && e.status === 400) {
        if (
          msgLower.includes('trùng') ||
          msgLower.includes('same') ||
          msgLower.includes('mật khẩu cũ') ||
          msgLower.includes('old password')
        ) {
          this.errorKind.set('sameAsOldPassword')
        } else if (
          msgLower.includes('token') ||
          msgLower.includes('hết hạn') ||
          msgLower.includes('expired') ||
          msgLower.includes('invalid')
        ) {
          this.errorKind.set('invalidToken')
        } else {
          this.errorKind.set('generic')
        }
        this.errorDetail.set(serverMessage)
      } else {
        this.errorKind.set('generic')
        this.errorDetail.set(serverMessage || null)
      }
    }
  }
}
